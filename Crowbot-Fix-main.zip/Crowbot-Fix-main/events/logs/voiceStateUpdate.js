const axios = require('axios');
const db = require("quick.db")
const {
	MessageEmbed
} = require("discord.js");
const ms = require("ms")

module.exports = (client, oldState, newState) => {
	const guild = oldState.guild


};
